<div id="spinner-overlay" class="flex justify-center items-center fixed top-0 left-0 w-full h-full bg-white bg-opacity-80 z-50">
    <div id="spinner-container" class="p-4 bg-white rounded">
        <img src="{{ asset('uploads/loading.jpg') }}" alt="Loading..." />
    </div>
</div>