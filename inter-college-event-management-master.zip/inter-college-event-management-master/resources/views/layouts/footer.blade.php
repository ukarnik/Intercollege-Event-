<div class="max-w-screen-2xl mx-auto">
    <div class="px-24">
        <hr>
        <div class="grid grid-cols-12 py-8">
            <div class="text-2xl font-bold">
                <a href="">ICEM</a>
            </div>
            <div>
                <a href="">Privacy</a>
            </div>
            <div>
                <a href="">About</a>
            </div>
            <div>
                <a href="">Terms</a>
            </div>
        </div>
    </div>
</div>